import React from 'react';
import { HashRouter, Routes, Route } from 'react-router-dom';
import ThresholdPage from './components/ThresholdPage';
import SelectionPage from './components/SelectionPage';
import RitualDetailsPage from './components/RitualDetailsPage';
import ContributePage from './components/ContributePage';
import SuccessPage from './components/SuccessPage';

const App: React.FC = () => {
  return (
    <HashRouter>
      <Routes>
        <Route path="/" element={<ThresholdPage />} />
        <Route path="/selection" element={<SelectionPage />} />
        <Route path="/ritual-details" element={<RitualDetailsPage />} />
        <Route path="/contribute" element={<ContributePage />} />
        <Route path="/success" element={<SuccessPage />} />
      </Routes>
    </HashRouter>
  );
};

export default App;