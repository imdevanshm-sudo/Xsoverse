import React from 'react';
import { useNavigate } from 'react-router-dom';

const SuccessPage: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-[#F8F8F6] flex flex-col items-center justify-center p-6 antialiased relative overflow-hidden font-manrope">
      
      <div className="w-full max-w-[85%] md:max-w-sm z-10 flex flex-col items-center space-y-12 animate-fade-in-up">
        
        {/* Header */}
        <div className="text-center space-y-4">
          <p className="text-gray-400 text-sm italic">Nothing else is required.</p>
          <h1 className="text-3xl font-light text-[var(--text-dark)] tracking-tight font-serif">
            Your Exso is ready
          </h1>
        </div>

        {/* Link Section */}
        <div className="w-full space-y-12">
          <div className="space-y-4">
            <div className="flex items-center justify-between border-b border-gray-200 pb-4">
              <span className="text-sm text-[var(--text-dark)] opacity-60 font-mono tracking-wide">
                exso.io/l/8x92m...
              </span>
              <button className="text-xs text-gray-400 hover:text-gray-600 transition-colors uppercase tracking-widest font-medium">
                Copy
              </button>
            </div>
          </div>

          {/* Share Options */}
          <div className="flex flex-col gap-6 items-center">
            <button className="text-gray-400 hover:text-gray-600 text-sm font-light flex items-center gap-2">
              Share via WhatsApp
            </button>
            <button className="text-gray-400 hover:text-gray-600 text-sm font-light flex items-center gap-2">
              Download QR
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="pt-12">
          <button 
            onClick={() => navigate('/')} 
            className="text-gray-300 text-xs uppercase tracking-[0.2em] hover:text-gray-500 transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

export default SuccessPage;