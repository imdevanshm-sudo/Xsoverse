import React from 'react';
import { useNavigate } from 'react-router-dom';

const ContributePage: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="bg-soft-cream flex flex-col items-center justify-center min-h-screen px-8 py-12 antialiased font-sans">
      <main className="w-full max-w-sm flex flex-col items-center text-center space-y-16 animate-fade-in-up">
        
        <header>
          <p className="text-gray-500 text-lg font-light italic leading-relaxed">
            Nothing here needs to be explained or performed.
          </p>
        </header>

        <section className="w-full flex flex-col items-center space-y-6">
          <button 
            onClick={() => navigate('/success')} 
            className="w-full py-4 px-6 flex items-center justify-center transition-colors duration-300 text-gray-400 hover:text-gray-600 rounded-full hover:bg-white/50"
          >
            <span className="text-sm tracking-wide font-light">
              Ready to continue
            </span>
          </button>
        </section>

      </main>
    </div>
  );
};

export default ContributePage;