import React from 'react';
import { useNavigate } from 'react-router-dom';

const SelectionPage: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="bg-[#D4D3CD] min-h-screen flex flex-col items-center justify-center p-5 font-serif transition-colors duration-500">
      <main className="w-full max-w-md mx-auto space-y-12">
        <header className="text-center px-4 space-y-4 animate-fade-in-up">
          <p className="text-sm text-[#222220]/60 italic font-sans">
            There is no right way to be present.
          </p>
          <h1 className="text-[26px] leading-[1.2] text-[#222220] font-medium tracking-[-0.5px]">
            Would you like to be known, or let the message stand alone?
          </h1>
        </header>

        <section className="grid grid-cols-2 w-full gap-4">
          <button 
            onClick={() => navigate('/ritual-details')} 
            className="option-card rounded-[20px] shadow-sm flex items-center justify-center p-6 bg-[#F2F2F0] hover:bg-[#F2F2F0]/80 transition-all text-center"
          >
            <span className="font-sans text-[14px] font-normal text-[#000000]">
              With my name
            </span>
          </button>
          
          <button 
            onClick={() => navigate('/ritual-details')} 
            className="option-card rounded-[20px] shadow-sm flex items-center justify-center p-6 bg-[#F2F2F0] hover:bg-[#F2F2F0]/80 transition-all text-center"
          >
            <span className="font-sans text-[14px] font-normal text-[#000000]">
              In silence
            </span>
          </button>
        </section>
      </main>
    </div>
  );
};

export default SelectionPage;