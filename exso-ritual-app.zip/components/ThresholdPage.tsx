import React from 'react';
import { useNavigate } from 'react-router-dom';
import { RitualOption } from '../types';

const RITUALS: RitualOption[] = [
  { id: 'quiet', title: 'Quiet Presence', subtitle: 'To let them know you are simply there.', bgClass: 'bg-[#ECECEE]' },
  { id: 'anchor', title: 'The Anchor', subtitle: 'For grounding when things feel unmoored.', bgClass: 'bg-[#E8ECE9]' },
  { id: 'light', title: 'A Soft Light', subtitle: 'To hold space for their shadows.', bgClass: 'bg-[#EFEBE9]' },
];

const ThresholdPage: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="bg-background-light dark:bg-background-dark text-slate-800 dark:text-slate-200 min-h-screen flex flex-col overflow-x-hidden selection:bg-primary/20 selection:text-primary transition-colors duration-500 font-display relative">
      <div className="flex-grow flex flex-col items-center justify-center p-6 w-full max-w-md mx-auto relative z-10">
        
        {/* Header Text */}
        <div className="w-full text-center mb-24 mt-12 animate-fade-in-up">
          <h1 className="text-3xl md:text-4xl font-light tracking-wide leading-tight text-primary/90 dark:text-white mb-12 drop-shadow-sm">
            For the words that haven't found their way.
          </h1>
          <p className="text-lg md:text-xl font-light text-slate-400 dark:text-slate-500 italic leading-relaxed max-w-xs mx-auto mb-16">
            A space to share a feeling when the silence feels too heavy.
          </p>
        </div>

        {/* Ritual Cards */}
        <div className="w-full flex flex-col gap-8 relative">
          {RITUALS.map((ritual) => (
            <label 
              key={ritual.id} 
              onClick={() => navigate('/selection')} 
              className="group relative cursor-pointer block transform transition-transform duration-300 hover:scale-[1.02]"
            >
              <div className={`relative overflow-hidden rounded-xl p-8 transition-all duration-500 ease-out ${ritual.bgClass} dark:bg-slate-800/60 shadow-sm border border-transparent`}>
                <div className="relative z-10 flex flex-col gap-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xl font-medium text-slate-900 dark:text-slate-100 transition-colors duration-300">
                      {ritual.title}
                    </span>
                  </div>
                  <span className="text-base font-normal text-slate-500 dark:text-slate-400 italic">
                    {ritual.subtitle}
                  </span>
                </div>
              </div>
            </label>
          ))}
        </div>

        {/* Footer Link */}
        <div className="mt-12 mb-12">
          <button className="text-sm text-slate-400 hover:text-slate-500 transition-colors">
            More ways to share
          </button>
        </div>
      </div>

      {/* Background Texture */}
      <div 
        className="fixed inset-0 pointer-events-none opacity-[0.03] z-0" 
        style={{
          backgroundImage: "url('https://lh3.googleusercontent.com/aida-public/AB6AXuAUp2Y2H8mvbCRXA85uFLWDWEvh9zOE5h3SdYc3-SZFhSLsSmN4HlGYnWM3dIei5uh9tixAzwsk6W0PZsMjMJy-y8psGwXsBdVo6hoDRWtZNOsvqXMvLLLgPoYyRjgdzfABnSInrtgORw7cpbxImeBUlpBXhMLCh-JKV7YaxsWyILB02OCk0h3R65eCIs9A6HmwkXy_jMtRatShp_ynl6hRKZTmmfc35oqmTAfkLITMYUCk4w-UToQP8W55M8JLkkzANSbwRrkRl2c')", 
          backgroundRepeat: 'repeat'
        }}
      />
    </div>
  );
};

export default ThresholdPage;