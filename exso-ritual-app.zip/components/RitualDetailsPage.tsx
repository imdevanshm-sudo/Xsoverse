import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const RitualDetailsPage: React.FC = () => {
  const [selection, setSelection] = useState<'message' | 'me'>('me');
  const navigate = useNavigate();

  return (
    <div className="min-h-screen flex flex-col bg-[#F7F8FA] text-gray-800 font-sans">
      
      {/* Navbar */}
      <header className="flex items-center p-6 pb-2">
        <button 
          onClick={() => navigate(-1)} 
          className="text-gray-400 p-2 -ml-2 hover:text-gray-600 transition-colors rounded-full hover:bg-gray-100"
        >
          <span className="material-symbols-outlined text-2xl">arrow_back</span>
        </button>
      </header>

      {/* Main Content */}
      <main className="flex-grow px-6 pt-12 pb-24 max-w-md mx-auto w-full">
        <section className="mb-12 animate-fade-in-up">
          <h2 className="text-gray-900 font-normal text-center text-xl leading-snug px-2">
            Do you want this message to be about the message, or about you?
          </h2>
        </section>

        <section className="space-y-6">
          {/* Option 1: About Message */}
          <div 
            onClick={() => setSelection('message')}
            className={`rounded-3xl p-6 flex items-center justify-between border transition-all cursor-pointer duration-300 ease-out ${
              selection === 'message' 
                ? 'bg-white border-gray-200 shadow-sm scale-[1.02]' 
                : 'bg-transparent border-transparent opacity-60 hover:opacity-100'
            }`}
          >
            <div className="flex items-center gap-4">
              <div>
                <p className="text-gray-900 font-medium">About the message</p>
              </div>
            </div>
            <div className={`w-4 h-4 rounded-full flex items-center justify-center border ${
              selection === 'message' ? 'border-gray-800' : 'border-gray-300'
            }`}>
                 {selection === 'message' && <div className="w-2 h-2 bg-gray-800 rounded-full" />}
            </div>
          </div>

          {/* Option 2: About Me */}
          <div 
            onClick={() => setSelection('me')}
            className={`rounded-3xl p-6 transition-all cursor-pointer relative border duration-300 ease-out ${
              selection === 'me' 
                ? 'bg-white border-gray-200 shadow-sm scale-[1.02]' 
                : 'bg-transparent border-transparent opacity-60 hover:opacity-100'
            }`}
          >
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-4">
                <div>
                  <p className="text-gray-900 font-medium">About me</p>
                </div>
              </div>
              <div className={`w-4 h-4 rounded-full flex items-center justify-center border ${
                selection === 'me' ? 'border-gray-800' : 'border-gray-300'
              }`}>
                   {selection === 'me' && <div className="w-2 h-2 bg-gray-800 rounded-full" />}
              </div>
            </div>
            
            {/* Conditional Content for "About Me" */}
            <div className={`px-2 py-3 flex flex-col gap-2 transition-opacity duration-300 ${selection === 'me' ? 'opacity-100' : 'opacity-50'}`}>
              <div className="flex justify-between items-center border-b border-gray-100 pb-2">
                <span className="text-gray-900 font-light text-lg">Alex</span>
              </div>
              <p className="text-[11px] text-gray-400 italic">This will only be seen if you choose it.</p>
            </div>
          </div>
        </section>
      </main>

      {/* Footer / CTA */}
      <footer className="fixed bottom-0 left-0 w-full p-6 bg-[#F7F8FA] border-t border-transparent">
        <div className="max-w-md mx-auto">
            <button 
            onClick={() => navigate('/contribute')} 
            className="w-full text-gray-500 font-normal text-base py-4 hover:text-gray-800 transition-colors flex items-center justify-center gap-2 hover:bg-gray-100 rounded-xl"
            >
            Continue
            </button>
        </div>
      </footer>
    </div>
  );
};

export default RitualDetailsPage;